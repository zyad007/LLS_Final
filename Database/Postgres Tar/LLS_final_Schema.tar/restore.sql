--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.18 (Ubuntu 11.18-1.pgdg20.04+1)
-- Dumped by pg_dump version 14.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ypmgugre;
--
-- Name: ypmgugre; Type: DATABASE; Schema: -; Owner: ypmgugre
--

CREATE DATABASE ypmgugre WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE ypmgugre OWNER TO ypmgugre;

\connect ypmgugre

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: cube; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS cube WITH SCHEMA public;


--
-- Name: EXTENSION cube; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION cube IS 'data type for multidimensional cubes';


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: dict_int; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dict_int WITH SCHEMA public;


--
-- Name: EXTENSION dict_int; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_int IS 'text search dictionary template for integers';


--
-- Name: dict_xsyn; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dict_xsyn WITH SCHEMA public;


--
-- Name: EXTENSION dict_xsyn; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_xsyn IS 'text search dictionary template for extended synonym processing';


--
-- Name: earthdistance; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS earthdistance WITH SCHEMA public;


--
-- Name: EXTENSION earthdistance; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION earthdistance IS 'calculate great-circle distances on the surface of the Earth';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: intarray; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS intarray WITH SCHEMA public;


--
-- Name: EXTENSION intarray; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION intarray IS 'functions, operators, and index support for 1-D arrays of integers';


--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: pgrowlocks; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgrowlocks WITH SCHEMA public;


--
-- Name: EXTENSION pgrowlocks; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgrowlocks IS 'show row-level locking information';


--
-- Name: pgstattuple; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgstattuple WITH SCHEMA public;


--
-- Name: EXTENSION pgstattuple; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgstattuple IS 'show tuple-level statistics';


--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: xml2; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS xml2 WITH SCHEMA public;


--
-- Name: EXTENSION xml2; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION xml2 IS 'XPath querying and XSLT';


SET default_tablespace = '';

--
-- Name: AspNetRoleClaims; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetRoleClaims" (
    "Id" integer NOT NULL,
    "RoleId" text NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


ALTER TABLE public."AspNetRoleClaims" OWNER TO ypmgugre;

--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: ypmgugre
--

ALTER TABLE public."AspNetRoleClaims" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."AspNetRoleClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: AspNetRoles; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetRoles" (
    "Id" text NOT NULL,
    "Name" character varying(256),
    "NormalizedName" character varying(256),
    "ConcurrencyStamp" text
);


ALTER TABLE public."AspNetRoles" OWNER TO ypmgugre;

--
-- Name: AspNetUserClaims; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetUserClaims" (
    "Id" integer NOT NULL,
    "UserId" text NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


ALTER TABLE public."AspNetUserClaims" OWNER TO ypmgugre;

--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: ypmgugre
--

ALTER TABLE public."AspNetUserClaims" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."AspNetUserClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: AspNetUserLogins; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetUserLogins" (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" text NOT NULL
);


ALTER TABLE public."AspNetUserLogins" OWNER TO ypmgugre;

--
-- Name: AspNetUserRoles; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetUserRoles" (
    "UserId" text NOT NULL,
    "RoleId" text NOT NULL
);


ALTER TABLE public."AspNetUserRoles" OWNER TO ypmgugre;

--
-- Name: AspNetUserTokens; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetUserTokens" (
    "UserId" text NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


ALTER TABLE public."AspNetUserTokens" OWNER TO ypmgugre;

--
-- Name: AspNetUsers; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."AspNetUsers" (
    "Id" text NOT NULL,
    "UserName" character varying(256),
    "NormalizedUserName" character varying(256),
    "Email" character varying(256),
    "NormalizedEmail" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "PasswordHash" text,
    "SecurityStamp" text,
    "ConcurrencyStamp" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "TwoFactorEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp with time zone,
    "LockoutEnabled" boolean NOT NULL,
    "AccessFailedCount" integer NOT NULL
);


ALTER TABLE public."AspNetUsers" OWNER TO ypmgugre;

--
-- Name: Courses; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Courses" (
    "Id" uuid NOT NULL,
    "Name" text,
    "Idd" uuid NOT NULL,
    "Code" text,
    "Description" text,
    "StartDate" timestamp without time zone NOT NULL,
    "EndDate" timestamp without time zone NOT NULL,
    "NumberOfStudents" integer NOT NULL,
    "NumberOfExp" integer NOT NULL,
    "AddedDate" timestamp without time zone NOT NULL,
    "UpdateDate" timestamp without time zone NOT NULL
);


ALTER TABLE public."Courses" OWNER TO ypmgugre;

--
-- Name: Exp_Courses; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Exp_Courses" (
    "Id" uuid NOT NULL,
    "ExperimentId" uuid NOT NULL,
    "CourseId" uuid NOT NULL,
    "StartDate" timestamp without time zone NOT NULL,
    "EndDate" timestamp without time zone NOT NULL,
    "NumbersOfTrials" integer NOT NULL
);


ALTER TABLE public."Exp_Courses" OWNER TO ypmgugre;

--
-- Name: Expirments; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Expirments" (
    "Id" uuid NOT NULL,
    "Name" text,
    "Idd" uuid NOT NULL,
    "AuthorId" text,
    "AuthorName" text,
    "LLO" text,
    "LLO_MA" text,
    "LLO_SA" text,
    "Description" text,
    "AddedDate" timestamp without time zone NOT NULL,
    "UpdateDate" timestamp without time zone NOT NULL,
    "Active" boolean DEFAULT false NOT NULL,
    "Editable" boolean DEFAULT false NOT NULL,
    "hasLLO" boolean DEFAULT false NOT NULL,
    "RelatedCourse" text
);


ALTER TABLE public."Expirments" OWNER TO ypmgugre;

--
-- Name: Machine; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Machine" (
    "Id" uuid NOT NULL,
    "Name" text,
    "IP" text
);


ALTER TABLE public."Machine" OWNER TO ypmgugre;

--
-- Name: RefreshTokens; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."RefreshTokens" (
    "Id" integer NOT NULL,
    "UserId" text,
    "Token" text,
    "JwtId" text,
    "IsUsed" boolean NOT NULL,
    "IsRevorked" boolean NOT NULL,
    "AddedDate" timestamp without time zone NOT NULL,
    "ExpirayDate" timestamp without time zone NOT NULL
);


ALTER TABLE public."RefreshTokens" OWNER TO ypmgugre;

--
-- Name: RefreshTokens_Id_seq; Type: SEQUENCE; Schema: public; Owner: ypmgugre
--

ALTER TABLE public."RefreshTokens" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."RefreshTokens_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Resource_Exps; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Resource_Exps" (
    "Id" uuid NOT NULL,
    "ExperimentId" uuid NOT NULL,
    "ResourceId" uuid NOT NULL
);


ALTER TABLE public."Resource_Exps" OWNER TO ypmgugre;

--
-- Name: Resource_Machine; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Resource_Machine" (
    "Id" uuid NOT NULL,
    "MachineId" uuid NOT NULL,
    "ResourceId" uuid NOT NULL
);


ALTER TABLE public."Resource_Machine" OWNER TO ypmgugre;

--
-- Name: Resources; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Resources" (
    "Id" uuid NOT NULL,
    "Name" text
);


ALTER TABLE public."Resources" OWNER TO ypmgugre;

--
-- Name: StudentCourse_ExpCourses; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."StudentCourse_ExpCourses" (
    "Id" uuid NOT NULL,
    "Student_CourseId" uuid NOT NULL,
    "Exp_CourseId" uuid NOT NULL,
    "IsCompleted" boolean DEFAULT false NOT NULL,
    "NumberOfTials" integer DEFAULT 0 NOT NULL,
    "FinalGrade" real DEFAULT 0 NOT NULL,
    feedback text,
    "EndAt" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL,
    "ReservedDay" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL,
    "StartFrom" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL,
    "Status" text,
    "TimeSlot" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."StudentCourse_ExpCourses" OWNER TO ypmgugre;

--
-- Name: StudentSessions; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."StudentSessions" (
    "Id" uuid NOT NULL,
    "StudentId" uuid NOT NULL,
    "ExpCourseId" uuid NOT NULL,
    "MachineId" uuid,
    "TimeSlot" integer NOT NULL
);


ALTER TABLE public."StudentSessions" OWNER TO ypmgugre;

--
-- Name: Trials; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Trials" (
    "Id" uuid NOT NULL,
    "StudentCourse_ExpCourseId" uuid NOT NULL,
    "TrialNumber" integer NOT NULL,
    "TotalScore" real NOT NULL,
    "TotalTimeInMin" real NOT NULL,
    "LLA" text,
    "LRO" text,
    "IsGraded" boolean DEFAULT false NOT NULL,
    "SubmitedAt" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL,
    "StartedAt" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL,
    "Status" text
);


ALTER TABLE public."Trials" OWNER TO ypmgugre;

--
-- Name: User_Courses; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."User_Courses" (
    "Id" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "CourseId" uuid NOT NULL,
    "Role" text,
    "Update" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE public."User_Courses" OWNER TO ypmgugre;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."Users" (
    "Id" uuid NOT NULL,
    "IdentityId" uuid NOT NULL,
    "FirstName" text,
    "Lastname" text,
    "Email" text,
    "PhoneNumber" text,
    "Country" text,
    "Role" text,
    "AcademicYear" text,
    "AddedDate" timestamp without time zone NOT NULL,
    "UpdateDate" timestamp without time zone NOT NULL,
    "Idd" uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    "City" text,
    "Gender" text,
    "imgURL" text,
    "LastLogIn" timestamp without time zone DEFAULT '0001-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE public."Users" OWNER TO ypmgugre;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: ypmgugre
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO ypmgugre;

--
-- Name: AspNetRoleClaims PK_AspNetRoleClaims; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "PK_AspNetRoleClaims" PRIMARY KEY ("Id");


--
-- Name: AspNetRoles PK_AspNetRoles; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetRoles"
    ADD CONSTRAINT "PK_AspNetRoles" PRIMARY KEY ("Id");


--
-- Name: AspNetUserClaims PK_AspNetUserClaims; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "PK_AspNetUserClaims" PRIMARY KEY ("Id");


--
-- Name: AspNetUserLogins PK_AspNetUserLogins; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "PK_AspNetUserLogins" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: AspNetUserRoles PK_AspNetUserRoles; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "PK_AspNetUserRoles" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: AspNetUserTokens PK_AspNetUserTokens; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "PK_AspNetUserTokens" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: AspNetUsers PK_AspNetUsers; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUsers"
    ADD CONSTRAINT "PK_AspNetUsers" PRIMARY KEY ("Id");


--
-- Name: Courses PK_Courses; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Courses"
    ADD CONSTRAINT "PK_Courses" PRIMARY KEY ("Id");


--
-- Name: Exp_Courses PK_Exp_Courses; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Exp_Courses"
    ADD CONSTRAINT "PK_Exp_Courses" PRIMARY KEY ("Id");


--
-- Name: Expirments PK_Expirments; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Expirments"
    ADD CONSTRAINT "PK_Expirments" PRIMARY KEY ("Id");


--
-- Name: Machine PK_Machine; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Machine"
    ADD CONSTRAINT "PK_Machine" PRIMARY KEY ("Id");


--
-- Name: RefreshTokens PK_RefreshTokens; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."RefreshTokens"
    ADD CONSTRAINT "PK_RefreshTokens" PRIMARY KEY ("Id");


--
-- Name: Resource_Exps PK_Resource_Exps; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resource_Exps"
    ADD CONSTRAINT "PK_Resource_Exps" PRIMARY KEY ("Id");


--
-- Name: Resource_Machine PK_Resource_Machine; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resource_Machine"
    ADD CONSTRAINT "PK_Resource_Machine" PRIMARY KEY ("Id");


--
-- Name: Resources PK_Resources; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resources"
    ADD CONSTRAINT "PK_Resources" PRIMARY KEY ("Id");


--
-- Name: StudentCourse_ExpCourses PK_StudentCourse_ExpCourses; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentCourse_ExpCourses"
    ADD CONSTRAINT "PK_StudentCourse_ExpCourses" PRIMARY KEY ("Id");


--
-- Name: StudentSessions PK_StudentSessions; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentSessions"
    ADD CONSTRAINT "PK_StudentSessions" PRIMARY KEY ("Id");


--
-- Name: Trials PK_Trials; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Trials"
    ADD CONSTRAINT "PK_Trials" PRIMARY KEY ("Id");


--
-- Name: User_Courses PK_User_Courses; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."User_Courses"
    ADD CONSTRAINT "PK_User_Courses" PRIMARY KEY ("Id");


--
-- Name: Users PK_Users; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_Users" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "EmailIndex" ON public."AspNetUsers" USING btree ("NormalizedEmail");


--
-- Name: IX_AspNetRoleClaims_RoleId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_AspNetRoleClaims_RoleId" ON public."AspNetRoleClaims" USING btree ("RoleId");


--
-- Name: IX_AspNetUserClaims_UserId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_AspNetUserClaims_UserId" ON public."AspNetUserClaims" USING btree ("UserId");


--
-- Name: IX_AspNetUserLogins_UserId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_AspNetUserLogins_UserId" ON public."AspNetUserLogins" USING btree ("UserId");


--
-- Name: IX_AspNetUserRoles_RoleId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_AspNetUserRoles_RoleId" ON public."AspNetUserRoles" USING btree ("RoleId");


--
-- Name: IX_Exp_Courses_CourseId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Exp_Courses_CourseId" ON public."Exp_Courses" USING btree ("CourseId");


--
-- Name: IX_Exp_Courses_ExperimentId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Exp_Courses_ExperimentId" ON public."Exp_Courses" USING btree ("ExperimentId");


--
-- Name: IX_RefreshTokens_UserId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_RefreshTokens_UserId" ON public."RefreshTokens" USING btree ("UserId");


--
-- Name: IX_Resource_Exps_ExperimentId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Resource_Exps_ExperimentId" ON public."Resource_Exps" USING btree ("ExperimentId");


--
-- Name: IX_Resource_Exps_ResourceId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Resource_Exps_ResourceId" ON public."Resource_Exps" USING btree ("ResourceId");


--
-- Name: IX_Resource_Machine_MachineId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Resource_Machine_MachineId" ON public."Resource_Machine" USING btree ("MachineId");


--
-- Name: IX_Resource_Machine_ResourceId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Resource_Machine_ResourceId" ON public."Resource_Machine" USING btree ("ResourceId");


--
-- Name: IX_StudentCourse_ExpCourses_Exp_CourseId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_StudentCourse_ExpCourses_Exp_CourseId" ON public."StudentCourse_ExpCourses" USING btree ("Exp_CourseId");


--
-- Name: IX_StudentCourse_ExpCourses_Student_CourseId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_StudentCourse_ExpCourses_Student_CourseId" ON public."StudentCourse_ExpCourses" USING btree ("Student_CourseId");


--
-- Name: IX_StudentSessions_ExpCourseId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_StudentSessions_ExpCourseId" ON public."StudentSessions" USING btree ("ExpCourseId");


--
-- Name: IX_StudentSessions_MachineId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_StudentSessions_MachineId" ON public."StudentSessions" USING btree ("MachineId");


--
-- Name: IX_StudentSessions_StudentId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_StudentSessions_StudentId" ON public."StudentSessions" USING btree ("StudentId");


--
-- Name: IX_Trials_StudentCourse_ExpCourseId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_Trials_StudentCourse_ExpCourseId" ON public."Trials" USING btree ("StudentCourse_ExpCourseId");


--
-- Name: IX_User_Courses_CourseId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_User_Courses_CourseId" ON public."User_Courses" USING btree ("CourseId");


--
-- Name: IX_User_Courses_UserId; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE INDEX "IX_User_Courses_UserId" ON public."User_Courses" USING btree ("UserId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE UNIQUE INDEX "RoleNameIndex" ON public."AspNetRoles" USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: ypmgugre
--

CREATE UNIQUE INDEX "UserNameIndex" ON public."AspNetUsers" USING btree ("NormalizedUserName");


--
-- Name: AspNetRoleClaims FK_AspNetRoleClaims_AspNetRoles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "FK_AspNetRoleClaims_AspNetRoles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserClaims FK_AspNetUserClaims_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "FK_AspNetUserClaims_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserLogins FK_AspNetUserLogins_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "FK_AspNetUserLogins_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserRoles FK_AspNetUserRoles_AspNetRoles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "FK_AspNetUserRoles_AspNetRoles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserRoles FK_AspNetUserRoles_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "FK_AspNetUserRoles_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserTokens FK_AspNetUserTokens_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "FK_AspNetUserTokens_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: Exp_Courses FK_Exp_Courses_Courses_CourseId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Exp_Courses"
    ADD CONSTRAINT "FK_Exp_Courses_Courses_CourseId" FOREIGN KEY ("CourseId") REFERENCES public."Courses"("Id") ON DELETE CASCADE;


--
-- Name: Exp_Courses FK_Exp_Courses_Expirments_ExperimentId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Exp_Courses"
    ADD CONSTRAINT "FK_Exp_Courses_Expirments_ExperimentId" FOREIGN KEY ("ExperimentId") REFERENCES public."Expirments"("Id") ON DELETE CASCADE;


--
-- Name: RefreshTokens FK_RefreshTokens_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."RefreshTokens"
    ADD CONSTRAINT "FK_RefreshTokens_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE RESTRICT;


--
-- Name: Resource_Exps FK_Resource_Exps_Expirments_ExperimentId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resource_Exps"
    ADD CONSTRAINT "FK_Resource_Exps_Expirments_ExperimentId" FOREIGN KEY ("ExperimentId") REFERENCES public."Expirments"("Id") ON DELETE CASCADE;


--
-- Name: Resource_Exps FK_Resource_Exps_Resources_ResourceId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resource_Exps"
    ADD CONSTRAINT "FK_Resource_Exps_Resources_ResourceId" FOREIGN KEY ("ResourceId") REFERENCES public."Resources"("Id") ON DELETE CASCADE;


--
-- Name: Resource_Machine FK_Resource_Machine_Machine_MachineId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resource_Machine"
    ADD CONSTRAINT "FK_Resource_Machine_Machine_MachineId" FOREIGN KEY ("MachineId") REFERENCES public."Machine"("Id") ON DELETE CASCADE;


--
-- Name: Resource_Machine FK_Resource_Machine_Resources_ResourceId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Resource_Machine"
    ADD CONSTRAINT "FK_Resource_Machine_Resources_ResourceId" FOREIGN KEY ("ResourceId") REFERENCES public."Resources"("Id") ON DELETE CASCADE;


--
-- Name: StudentCourse_ExpCourses FK_StudentCourse_ExpCourses_Exp_Courses_Exp_CourseId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentCourse_ExpCourses"
    ADD CONSTRAINT "FK_StudentCourse_ExpCourses_Exp_Courses_Exp_CourseId" FOREIGN KEY ("Exp_CourseId") REFERENCES public."Exp_Courses"("Id") ON DELETE CASCADE;


--
-- Name: StudentCourse_ExpCourses FK_StudentCourse_ExpCourses_User_Courses_Student_CourseId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentCourse_ExpCourses"
    ADD CONSTRAINT "FK_StudentCourse_ExpCourses_User_Courses_Student_CourseId" FOREIGN KEY ("Student_CourseId") REFERENCES public."User_Courses"("Id") ON DELETE CASCADE;


--
-- Name: StudentSessions FK_StudentSessions_Exp_Courses_ExpCourseId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentSessions"
    ADD CONSTRAINT "FK_StudentSessions_Exp_Courses_ExpCourseId" FOREIGN KEY ("ExpCourseId") REFERENCES public."Exp_Courses"("Id") ON DELETE CASCADE;


--
-- Name: StudentSessions FK_StudentSessions_Machine_MachineId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentSessions"
    ADD CONSTRAINT "FK_StudentSessions_Machine_MachineId" FOREIGN KEY ("MachineId") REFERENCES public."Machine"("Id") ON DELETE RESTRICT;


--
-- Name: StudentSessions FK_StudentSessions_Users_StudentId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."StudentSessions"
    ADD CONSTRAINT "FK_StudentSessions_Users_StudentId" FOREIGN KEY ("StudentId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: Trials FK_Trials_StudentCourse_ExpCourses_StudentCourse_ExpCourseId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."Trials"
    ADD CONSTRAINT "FK_Trials_StudentCourse_ExpCourses_StudentCourse_ExpCourseId" FOREIGN KEY ("StudentCourse_ExpCourseId") REFERENCES public."StudentCourse_ExpCourses"("Id") ON DELETE CASCADE;


--
-- Name: User_Courses FK_User_Courses_Courses_CourseId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."User_Courses"
    ADD CONSTRAINT "FK_User_Courses_Courses_CourseId" FOREIGN KEY ("CourseId") REFERENCES public."Courses"("Id") ON DELETE CASCADE;


--
-- Name: User_Courses FK_User_Courses_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: ypmgugre
--

ALTER TABLE ONLY public."User_Courses"
    ADD CONSTRAINT "FK_User_Courses_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: DATABASE ypmgugre; Type: ACL; Schema: -; Owner: ypmgugre
--

REVOKE CONNECT,TEMPORARY ON DATABASE ypmgugre FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT CREATE ON SCHEMA public TO ypmgugre;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT,UPDATE ON TABLE public.pg_stat_statements TO ypmgugre;


--
-- PostgreSQL database dump complete
--

